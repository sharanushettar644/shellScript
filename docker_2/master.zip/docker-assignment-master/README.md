# This is the sample project consist of client side app and server side app

You have to create two separate Dockerfile to build an image for both, Client side app and server side app

##### To download this project click https://github.com/aamirpinger/docker-assignment/archive/master.zip

### Client side (Folder name: node-client-app)
This directory contains a Client side Node.js app, you need to get it running in a container

### Server side (Folder name: node-server-app)
This directory contains a Server side Node.js app, you need to get it running in a container

No modifications to the app should be necessary, only add Dockerfile and build an image

## Instructions for Dockerfile can be checked in both folders
